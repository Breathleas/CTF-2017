# shopping

编译：

```shell
$ ./clang -O1 shopping.c -mllvm -sub -mllvm -bcf -mllvm -fla -w -o shopping
```

