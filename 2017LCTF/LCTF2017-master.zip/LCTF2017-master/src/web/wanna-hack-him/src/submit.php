<?php
error_reporting(0);
file_put_contents('loghehehaha.txt',$_POST['content']);
echo 'submit success :) good luck';
?>