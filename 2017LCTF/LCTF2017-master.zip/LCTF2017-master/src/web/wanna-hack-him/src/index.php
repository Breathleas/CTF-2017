<center>
<title>hello hacker hack him</title>
<form id="form1" action="preview.php" method="post" class="">
<h1>wanna hack him?
<span>Leave your message here!</span>
</h1>
<textarea name="content"></textarea>
<label>
</form>
<br>
<button onclick="form1.submit();">preview</button> <button onclick="form1.action='submit.php';form1.submit();">submit</button>
</center>