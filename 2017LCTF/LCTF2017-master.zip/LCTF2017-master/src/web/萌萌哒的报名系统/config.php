<?php
$user = "root";
$pass = "root";
$flag2333 = "lctf{pr3_maTch_1s_A_amaz1ng_Function}"
?>