# README

## Demo

// The note is ignored

VALUE 1 10
VALUE 2 20
ADD 1 2
PRINT 0
END

## List

* VALUE Reg Number
    
    Reg = Number

    Reg: int, 1~15

    Number: long int

* MOV Reg1 Reg2

    Reg1 = Reg2

    Reg1/Reg2: 0~15

* ADD/SUB/MUL/DEV Reg1 Reg2

    Res = Reg1 +|-|*|/ Reg2     

    Res: Reg 0

    Reg1/Reg2: 0~15

* PRINT Reg

    Reg: 0~15

* END

    end of file

